<?
include('geturl.php');
?>

<?php
session_start();

if(isset($_GET['lang']) && !empty($_GET['lang'])){
 $_SESSION['lang'] = $_GET['lang'];

 if(isset($_SESSION['lang']) && $_SESSION['lang'] != $_GET['lang']){
  echo "<script type='text/javascript'> location.reload(); </script>";
 }
}

if(isset($_SESSION['lang'])){
 include "lang_".$_SESSION['lang'].".php";
}else{
 include "lang_en.php";
}
?>

<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>.<?echo $yourdomain;?> | <?= _TITLE_HOMEPAGE ?></title>
    <meta name="description" content="<?= _DESCRIPTION ?>">
    <link href="bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <style>
input[type=text] {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
input[type=password] {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
.form-control {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
</style>
  </head>
  </body>
  
<script>
 function changeLang(){
  document.getElementById('form_lang').submit();
 }
 </script> 
  
<a href="http://<?echo $yourdomain;?>" class="btn btn-primary btn-block"><?= _SUB_DOMAIN ?> .<?echo $yourdomain;?></a>
<div class="container"><div class="row">
<div class="col-md-2"><p>
 <form method='get' action='' id='form_lang' >
   <?= _SELECT_LANGUAGE ?> <select class='form-control' name='lang' onchange='changeLang();' >
   <option value='en' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'en'){ echo "selected"; } ?> ><i class="flag flag-united-kingdom"></i><?= _ENGLISH ?></option>
   <option value='ka' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'ka'){ echo "selected"; } ?> ><i class="flag flag-georgia"></i><?= _GEORGIAN ?></option>
  </select>
 </form>
</p></div>
</div>
</div>
<center><h2><?= _WEB_HOSTING_TITLE ?></h2><br><?= _CREATE_WEBSITE_NOW ?><br></center><br>
<br><div class="container"><div class="row"><div class="col-md-6"><p>
<p><a class="btn btn-default" href="http://cpanel.<?echo $yourdomain;?>"><img src="assets/images/link.jpg" width: 100%; margin: 10px; padding: 5px;"> cpanel.<?echo $yourdomain;?></a> <?= _CONTROL_PANEL ?></p>
<p><hr>

<h3><?= _SITE_REGISTRATION ?></h3><form class='form-inline' action='signup.php' method='GET'><div class='form-group'><input type='text' name='subdomain' value='' placeholder='<?= _INPUT_SUB_DOMAIN ?>' pattern='[a-z0-9]{4,16}' minlength='4' maxlength='16' class='form-control' required><select class='form-control'><option>.<?echo $yourdomain;?></option><select></div>
<button type='submit' class='btn btn-primary'><?= _REGISTRATION ?></button></form>

<hr></p>
<p><br><b><?= _FREE_PLAN ?></b><br></p>
</p><br></div>
<div class="col-md-6"><p>
<br><img src="assets/images/website.jpg" alt="hosting"style="width:100%;"><br>
</p>
        </div>
    <br></div>
    <div class="col-md-100">
     <center><br><h3><?= _ABOUT ?></h3>
            <p><i><?= _ABOUT_TEXT ?></i><br></p><br>
</center><br></div><br><br></div><br>
<br><footer class="footer navbar navbar-default navbar-fixed-bottom">
    <div class="container">
        <div class="navbar-inner navbar-content-center" style="padding-top:15px;">
            <ul class="navbar-left list-inline text-center text-muted credit"><li>Copyright &copy; 2022 <small><?echo $yourdomain;?></small></li></ul>
            </ul>
             <ul class="navbar-right list-inline text-center text-muted credit">
                <li>
             <small><i>Powered by</i></small> <b><big>iFastNet</big></b>
                </li>
            </ul> 
</div></div>
</body>
</html>
