<?php

define("_TITLE", "Бесплатный поддомен и Бесплатный неограниченный веб-хостинг с поддержкой php");
define("_LOGIN", "Логин");
define("_USERNAME", "Имя пользователя");
define("_PASSWORD", "Пароль");
define("_REMEMBER", "Запомнить");
define("_SIGNIN", "Войти");
define("_REGISTER", "Регистрация");
define("_SUBDOMAIN", "Поддомен");
define("_EMAIL", "Электронная почта");
define("_CODE", "Защитный код");
define("_SIGNUP", "Регистрация");
