<?php

define("_TITLE", "უფასო ქვე-დომენი და უფასო შეუზღუდავი ვებ ჰოსტინგი php მხარდაჭერით");
define("_LOGIN", "შესვლა");
define("_USERNAME", "მომხმარებელი");
define("_PASSWORD", "პაროლი");
define("_REMEMBER", "დამახსოვრება");
define("_SIGNIN", "შესვლა");
define("_REGISTER", "რეგისტრაცია");
define("_SUBDOMAIN", "ქვე-დომენი");
define("_EMAIL", "ელ. ფოსტა");
define("_CODE", "დამცავი კოდი");
define("_SIGNUP", "რეგისტრაცია");
define("_MINIMUM", "მინიმუმი");
define("_MAXIMUM", "მაქსიმუმი");
define("_REQUIRED", "აუცილებელია");
define("_REMAINING", "დარჩენილია");
define("_ENGLISH", "ინგლისური");
define("_GEORGIAN", "ქართული");
define("_RUSSIAN", "რუსული");
