<?PHP
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>

<?php
session_start();

if(isset($_GET['lang']) && !empty($_GET['lang'])){
 $_SESSION['lang'] = $_GET['lang'];

 if(isset($_SESSION['lang']) && $_SESSION['lang'] != $_GET['lang']){
  echo "<script type='text/javascript'> location.reload(); </script>";
 }
}

if(isset($_SESSION['lang'])){
 include "lang_".$_SESSION['lang'].".php";
}else{
 include "lang_en.php";
}
?>

<?php
$subdomain = $_GET['subdomain'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?= _WEB_HOSTING_TITLE ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="description" content="<?= _DESCRIPTION ?>">
<link href="bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
<style>
input[type=text] {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
input[type=password] {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
.form-control {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #555;
  outline: none;
}
</style>
</head>
<body>

<script>
 function changeLang(){
  document.getElementById('form_lang').submit();
 }
 </script>
 
<a href="http://<?echo $yourdomain;?>/signup.php?subdomain=<?echo $subdomain;?>" class="btn btn-primary btn-block"><?= _PREMIUM_HOSTING ?></a>
<div class="container"><div class="row">
<div class="col-md-2"><p>
 <form method='get' action='' id='form_lang' >
   <?= _SELECT_LANGUAGE ?> <select class='form-control' name='lang' onchange='changeLang();' >
   <option value='en' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'en'){ echo "selected"; } ?> ><i class="flag flag-united-kingdom"></i><?= _ENGLISH ?></option>
   <option value='ka' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'ka'){ echo "selected"; } ?> ><i class="flag flag-georgia"></i><?= _GEORGIAN ?></option>
  </select>
  <input type=hidden name=subdomain value="<?echo $subdomain;?>">
 </form>
 </p></div>
</div>
</div>
<center><h2><?= _WEB_HOSTING_TITLE ?></h2><br><?= _CREATE_WEBSITE_NOW ?><br></center><br>
<div class="container"><div class="row">
<div class="col-md-6"><p>
<br><p><h3><?= _SITE_REGISTRATION ?></h3></p>
<form method=post action="http://order.<?echo $yourdomain;?>/register2.php">
<p><input type=hidden name=username value="<?echo $subdomain;?>"></p>
<p><input class="form-control" placeholder="<?= _PASSWORD ?>" type=password name=password pattern=".{6,16}" minlength="6" maxlength="16" required></p>
<p><small><?= _PASSWORD_TEXT ?></small></p>
<p><input class="form-control" placeholder="<?= _EMAIL ?>" type=text name=email pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" maxlength="30" required></p>
<p><small><?= _EMAIL_TEXT ?></small></p>		
<p><input type=hidden name=id value="<?PHP echo $id; ?>">
<p><img class="default" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"> <small><?= _CODE_IMAGE_TEXT ?></small></p>
<p><input class="form-control" placeholder="<?= _CODE ?>" type=text minlength="5" maxlength="5" name=number required></p>
<p><small><?= _CODE_TEXT ?></small></p>
<center><button type="submit" class="btn btn-primary"><?= _REGISTER ?></button></center><br>
</form></p></div>
<div class="col-md-6"><p><br>
<br><center>
<big><?= _REGISTRATION_IS_FREE ?></big><hr>
<i><small><?= _OUR ?> DNS Nameservers:</i></small><br>
<b>ns1.<?echo $yourdomain;?></b><br>
<b>ns2.<?echo $yourdomain;?></b><br>
<br><i><small>FTP <?= _SERVER ?>:</i></small><br>
<b>ftp.<?echo $yourdomain;?></b><br>
</center>
</p></div>
    <br></div>
    <div class="col-md-100">
     <br><center><br><p><a class="btn btn-default" href="http://<?echo $subdomain;?>.<?echo $yourdomain;?>" target="_blank"><img src="assets/images/link.jpg" width: 100%; margin: 10px; padding: 5px;"> <b><?echo $subdomain;?></b>.<?echo $yourdomain;?></a><br><h3><?= _DOMAIN_FOR_FREE ?><h3></p>
</center><br></div><br><br></div><br>
<br><footer class="footer navbar navbar-default navbar-fixed-bottom">
    <div class="container">
        <div class="navbar-inner navbar-content-center" style="padding-top:15px;">
            <ul class="navbar-left list-inline text-center text-muted credit"><li>Copyright &copy; 2022 <small><?echo $yourdomain;?></small></li></ul>
            </ul>
             <ul class="navbar-right list-inline text-center text-muted credit">
                <li>
          <small><i>Powered by</i></small> <b><big>iFastNet</big></b>
                </li>
            </ul> 
</div></div>
</body>
</html>
