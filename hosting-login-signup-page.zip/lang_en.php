<?php

define("_TITLE", "Free subdomain and Free unlimited web hosting with php support");
define("_LOGIN", "Login");
define("_USERNAME", "Username");
define("_PASSWORD", "Password");
define("_REMEMBER", "Remember");
define("_SIGNIN", "Sign In");
define("_REGISTER", "Register");
define("_SUBDOMAIN", "Subdomain");
define("_EMAIL", "Email Address");
define("_CODE", "Security Code");
define("_SIGNUP", "Sign Up");
