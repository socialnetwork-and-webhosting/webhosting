<?
include('signup.php');
?>
<footer class="footer navbar navbar-default navbar-fixed-bottom">
    <div class="container">
        <div class="navbar-inner navbar-content-center" style="padding-top:15px;">
            <ul class="navbar-left list-inline text-center text-muted credit"><li>&copy; 2022 <a href="http://<?echo $yourdomain;?>"><small><?echo $yourdomain;?></small></a></li></ul>
            </ul>
             <ul class="navbar-right list-inline text-center text-muted credit">
                <li>
            <!-- TOP.GE ASYNC COUNTER CODE -->
            <div id="top-ge-counter-container" data-site-id="116246"></div>
            <script async src="//counter.top.ge/counter.js"></script>
            <!-- / END OF TOP.GE COUNTER CODE -->
                </li>
            </ul> 
</div>
</body>
</html>
