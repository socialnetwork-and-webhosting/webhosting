<?PHP
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<?php
session_start();

if(isset($_GET['lang']) && !empty($_GET['lang'])){
 $_SESSION['lang'] = $_GET['lang'];

 if(isset($_SESSION['lang']) && $_SESSION['lang'] != $_GET['lang']){
  echo "<script type='text/javascript'> location.reload(); </script>";
 }
}

if(isset($_SESSION['lang'])){
 include "lang_".$_SESSION['lang'].".php";
}else{
 include "lang_en.php";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.<?echo $yourdomain;?> <?= _TITLE ?></title>
<script>
 function changeLang(){
  document.getElementById('form_lang').submit();
 }
</script>
<script src="jquery-1.9.1.js"></script>
<script>
            $(function() {
 
                if (localStorage.chkbx && localStorage.chkbx != '') {
                    $('#remember_me').attr('checked', 'checked');
                    $('#save_uname').val(localStorage.usrname);
                    $('#save_passwd').val(localStorage.pass);
                } else {
                    $('#remember_me').removeAttr('checked');
                    $('#save_uname').val('');
                    $('#save_passwd').val('');
                }
 
                $('#remember_me').click(function() {
 
                    if ($('#remember_me').is(':checked')) {
                        localStorage.usrname = $('#save_uname').val();
                        localStorage.pass = $('#save_passwd').val();
                        localStorage.chkbx = $('#remember_me').val();
                    } else {
                        localStorage.usrname = '';
                        localStorage.pass = '';
                        localStorage.chkbx = '';
                    }
                });
            });
 
        </script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
<link href="bootstrap.min.css" rel="stylesheet">
<style>
.block { background-color: #fafafa; border: 1px; border-style: dashed; border-color: #e1e1e1; border-radius: 5px 5px 5px 5px; padding: 5px; margin: 5px; }
</style>
</head>
<body>
<a href="/index.php" class="btn btn-primary btn-block"><?echo $yourdomain;?></a><br>
<div class="container"><div class="row">
<center>
<form method='get' action='' id='form_lang'>
<label>
   <input type="submit" value='en' name='lang' onchange='changeLang();' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'en'){ echo "class='btn btn-primary'"; } else echo 'class="btn btn-default"'; ?> >
</label>
<label>
   <input type="submit" value='ge' name='lang' onchange='changeLang();' <?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == 'ge'){ echo "class='btn btn-primary'"; } else echo 'class="btn btn-default"'; ?> >
</label>
</center>
<hr>
</form>
<div class="col-md-6"><p>
<form class="block" action="http://cpanel.<?echo $yourdomain;?>/login.php" method="post" name="login" >
<p>&nbsp;<font style="background-color: #fefefe; color: #000000; border: 5px solid; border-color: #fefefe; border-radius: 5px 5px 5px 5px;"><b><?= _LOGIN ?></b></font></p>
<p><input class="form-control" placeholder="<?= _USERNAME ?>" name="uname" type="text" alt="username" id="save_uname" required></p>
<p><input class="form-control" placeholder="<?= _PASSWORD ?>" type="password" name="passwd" alt="password" id="save_passwd" required></p>
<p><input type="checkbox" id="remember_me"> <?= _REMEMBER ?></p>
<p><input type="submit" name="Submit" value="<?= _SIGNIN ?>" class="btn btn-primary"/></p>
</form></p></br></div>
<div class="col-md-6"><p>
<form class="block" method=post action="http://order.<?echo $yourdomain;?>/register2.php">
<p>&nbsp;<font style="background-color: #fefefe; color: #000000; border: 5px solid; border-color: #fefefe; border-radius: 5px 5px 5px 5px;"><b><?= _REGISTER ?></b></font></p>
<p><input class="form-control" placeholder="<?= _SUBDOMAIN ?>" type=text name=username value="" pattern="[a-z0-9]{4,16}" maxlength="16" required></p>
<p><input class="form-control" placeholder="<?= _PASSWORD ?>" type=password name=password pattern=".{6,16}" maxlength="16" required></p>
<p><input class="form-control" placeholder="<?= _EMAIL ?>" type=text name=email pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" required></p>		
<p><input type=hidden name=id value="<?PHP echo $id; ?>">
<p><img src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"> </p>
<p><input class="form-control" placeholder="<?= _CODE ?>" type=text pattern=".{5,5}" name=number required></p>
<center><p><button type="submit" class="btn btn-primary"><?= _SIGNUP ?></button></p></center>
</form></br></p></br></div></br>
</br></div></br>
<footer class="footer navbar navbar-default navbar-fixed-bottom">
    <div class="container">
        <div class="navbar-inner navbar-content-center" style="padding-top:15px;">
            <ul class="navbar-left list-inline text-center text-muted credit"><li>&copy; 2022 <a href="http://<?echo $yourdomain;?>"><small><?echo $yourdomain;?></small></a></li></ul>
            </ul>
             <ul class="navbar-right list-inline text-center text-muted credit">
                <li>
<?php include 'banner.php' ?>
                </li>
            </ul> 
</div>
</body>
</html>

